function validarNumero() {
    let valorInput = document.getElementById("numero").value.trim();
    let mensagem = document.getElementById("mensagem");

    if (valorInput === "") {
        mensagem.textContent = "Por favor, insira um número.";
        mensagem.style.color = "red";
        return;
    }

    let numero = parseInt(valorInput);

    if (isNaN(numero)) {
        mensagem.textContent = "Isso não é um número válido!";
        mensagem.style.color = "red";
        return;
    }

    if (numero > 10) {
        mensagem.textContent = "O número é maior que 10.";
        mensagem.style.color = "green";
    } else if (numero > 5) {
        mensagem.textContent = "O número é maior que 5, mas menor ou igual a 10.";
        mensagem.style.color = "orange";
    } else {
        mensagem.textContent = "O número é menor ou igual a 5.";
        mensagem.style.color = "blue";
    }
}
